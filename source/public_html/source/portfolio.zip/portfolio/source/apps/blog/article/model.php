<?php
# -----------------------------
# ポートフォリオサイト本体 ブログ記事ページモデル
# 2018.09.29 s0hiba 初版作成
# 2019.01.20 s0hiba MyPDOクラスを使用開始
# 2019.03.23 s0hiba 入力チェックを導入
# 2019.03.24 s0hiba XSS対策導入
# 2019.11.24 s0hiba DB操作ログの保存を追加
# -----------------------------


//各種変数の初期化
$result = 2;
$postCheck = true;
$nowStamp = $nowDateTime->format('Y-m-d H:i:s');

//POSTリクエストの文字エンコーディングと制御文字をチェック
foreach ($postArray as $postData) {
    //POSTリクエストのデータが配列だった場合、全ての値を結合した文字列に変換
    if (is_array($postData)) {
        $postData = implode($postData);
    }

    //文字エンコーディングがUTF-8でない、もしくは制御文字を含むなら、チェック失敗とする
    if (!mb_check_encoding($postData, 'UTF-8') || preg_match('/[\x00-\x09\x0B\x0C\x0E-\x1F\x7F]/', $postData)) {
        $postCheck = false;
    }
}

//POSTリクエストの型と文字数をチェック
if (!isset($postArray['comment_title']) || !is_string($postArray['comment_title']) || mb_strlen($postArray['comment_title']) > 30
 || !isset($postArray['comment_user']) || !is_string($postArray['comment_user']) || mb_strlen($postArray['comment_user']) > 8
 || !isset($postArray['comment_text']) || !is_string($postArray['comment_text']) || mb_strlen($postArray['comment_text']) > 800) {
    $postCheck = false;
}

//POSTリクエストのチェック条件を満たしているなら、モデルの処理を実行
if ($postCheck) {
    //DBへ接続
    $myPdo = new MyPDO($dsn);

    //現在の日時を取得
    $nowStamp = $nowDateTime->format('Y-m-d H:i:s');

    //POSTリクエストのHTMLをエスケープ
    $commentTitle = htmlspecialchars($postArray['comment_title'], ENT_QUOTES | ENT_HTML5, 'UTF-8');
    $commentUser = htmlspecialchars($postArray['comment_user'], ENT_QUOTES | ENT_HTML5, 'UTF-8');
    $commentText = htmlspecialchars($postArray['comment_text'], ENT_QUOTES | ENT_HTML5, 'UTF-8');

    //DB作業を試みる
    try {
        //トランザクション開始
        $myPdo->beginTransaction();

        //コメントを追加
        $myPdo->setInsert('portfolio.blog_comment');
        $myPdo->setValue(array(
            array('key' => 'article_id',    'value' => $articleId,      'type' => PDO::PARAM_INT),
            array('key' => 'comment_title', 'value' => $commentTitle,   'type' => PDO::PARAM_STR),
            array('key' => 'comment_stamp', 'value' => $nowStamp,       'type' => PDO::PARAM_STR),
            array('key' => 'comment_user',  'value' => $commentUser,    'type' => PDO::PARAM_STR),
            array('key' => 'comment_text',  'value' => $commentText,    'type' => PDO::PARAM_STR),
        ));
        $myPdo->setReturning();
        $insertComment = $myPdo->getSqlResultRow();

        //エラーがなければコミット
        $myPdo->commit();

        //結果に成功フラグを立てる
        $result = 1;
    } catch (PDOException $e) {
        //エラーがあったらロールバック
        $myPdo->rollBack();
    }

    //Redisのコメント一覧を削除
    $redis->del("portfolio_comment_list_{$articleId}");
}

//DBを操作したログの書き込みを試みる
try {
    //トランザクション開始
    $myPdo->beginTransaction();

    //ログへ書き込むデータの配列を作成
    $logValue = array(
        array('key' => 'action_stamp', 'value' => $nowStamp, 'type' => PDO::PARAM_STR),
        array('key' => 'action_url', 'value' => "/blog/article/{$articleId}/", 'type' => PDO::PARAM_STR),
        array('key' => 'action_type_id', 'value' => 5, 'type' => PDO::PARAM_INT),
        array('key' => 'action_result', 'value' => $result, 'type' => PDO::PARAM_INT),
        array('key' => 'ip_address', 'value' => $_SERVER['REMOTE_ADDR'], 'type' => PDO::PARAM_STR),
        array('key' => 'action_db_table', 'value' => 'blog_comment', 'type' => PDO::PARAM_STR),
    );

    if (isset($insertComment['comment_id']) && ctype_digit(strval($insertComment['comment_id'])) && $insertComment['comment_id'] > 0) {
        $logValue[] = array('key' => 'action_data_id', 'value' => $insertComment['comment_id'], 'type' => PDO::PARAM_INT);
    }

    //ログを書き込み
    $myPdo->setInsert('portfolio.action_log');
    $myPdo->setValue($logValue);
    $myPdo->getSqlResultRow();

    //エラーがなければコミット
    $myPdo->commit();
} catch (PDOException $e) {
    //エラーがあったらロールバック
    $myPdo->rollBack();
}
