<?php
# -----------------------------
# ポートフォリオサイト本体 ブログ記事ページビュー
# 2018.07.20 s0hiba 初版作成
# 2019.01.03 s0hiba MyPDOクラスを使用開始
# 2019.01.28 s0hiba Redis導入
# 2021.01.13 s0hiba パス構造を変更
# -----------------------------


//Redisから最新ブログ記事5件の取得を試みる
$articleListNewJson = $redis->get('portfolio_article_list_new');
$articleListNew = json_decode($articleListNewJson, true);

//取得できなかった場合、DBから取得
if (empty($articleListNew)) {
    //DBへの接続が行われていない場合、ここで接続
    if (empty($myPdo)) {
        $myPdo = new MyPDO($dsn);
    }

    //データを取得
    $myPdo->setSelect('portfolio.blog_article');
    $myPdo->setOrder(array(
        'article_stamp DESC',
    ));
    $myPdo->setLimit(5);
    $articleListNew = $myPdo->getSqlResult();

    //DBから取得できた場合、Redisに保存
    if (!empty($articleListNew)) {
        $articleListNewJson = json_encode($articleListNew);
        $redis->set('portfolio_article_list_new', $articleListNewJson);
    }
}

//Redisからブログ記事種別の取得を試みる
$tagListJson = $redis->get('portfolio_tag_list');
$tagList = json_decode($tagListJson, true);

//取得できなかった場合、DBから取得
if (empty($tagList)) {
    //DBへの接続が行われていない場合、ここで接続
    if (empty($myPdo)) {
        $myPdo = new MyPDO($dsn);
    }

    //データを取得
    $myPdo->setSelect('portfolio.article_tag_master');
    $myPdo->setOrder(array(
        'article_sort_no ASC',
        'article_tag_id ASC',
    ));
    $tagList = $myPdo->getSqlResult();

    //DBから取得できた場合、Redisに保存
    if (!empty($tagList)) {
        $tagListJson = json_encode($tagList);
        $redis->set('portfolio_tag_list', $tagListJson);
    }
}

//Redisからブログ記事の投稿年月一覧の取得を試みる
$monthListJson = $redis->get('portfolio_month_list');
$monthList = json_decode($monthListJson, true);

//取得できなかった場合、DBの記事データから生成
if (empty($monthList)) {
    //DBへの接続が行われていない場合、ここで接続
    if (empty($myPdo)) {
        $myPdo = new MyPDO($dsn);
    }

    //ブログ記事を日付昇順で全件取得
    $myPdo->setSelect('portfolio.blog_article');
    $myPdo->setOrder(array(
        'article_stamp ASC',
    ));
    $articleListAsc = $myPdo->getSqlResult();

    //ブログ記事一覧から、ブログ記事の投稿年月一覧を作成
    if (isset($articleListAsc) && is_array($articleListAsc) && count($articleListAsc) > 0) {
        foreach ($articleListAsc as $articleData) {
            //投稿日時から年と月を取得
            $year = substr($articleData['article_stamp'], 0, 4);
            $month = substr($articleData['article_stamp'], 5, 2);

            //一覧を配列形式で作成
            $monthList[$year][$month] = $month;
        }
    }

    //生成できた場合、Redisに保存
    $monthListJson = json_encode($monthList);
    $redis->set('portfolio_month_list', $monthListJson);
}

//Redisから表示対象のブログ記事の取得を試みる
$articleDataJson = $redis->get("portfolio_article_data_{$articleId}");
$article = json_decode($articleDataJson, true);

//Redisから表示対象のブログ記事に対するコメントの取得を試みる
$commentListJson = $redis->get("portfolio_comment_list_{$articleId}");
$commentList = json_decode($commentListJson, true);

//DB作業を試みる
try {
    //表示対象のブログ記事をRedisから取得できなかった場合、
    //DBから取得する
    if (empty($article)) {
        //DBへの接続が行われていない場合、ここで接続
        if (empty($myPdo)) {
            $myPdo = new MyPDO($dsn);
        }

        //データを取得
        $myPdo->setSelect('portfolio.blog_article');
        $myPdo->setJoin(array(
            'portfolio.article_tag_master' => 'article_tag_id',
        ));
        $myPdo->setWhere(array(
            array('key' => 'article_id', 'value' => $articleId, 'operator' => '=', 'type' => PDO::PARAM_INT),
        ));
        $article = $myPdo->getSqlResultRow();

        //DBから取得できた場合、Redisに保存
        if (!empty($article)) {
            $articleDataJson = json_encode($article);
            $redis->set("portfolio_article_data_{$articleId}", $articleDataJson);
        }
    }

    //表示対象のブログ記事に対するコメントをRedisから取得できなかった場合、
    //DBから取得する
    if (empty($commentList)) {
        //DBへの接続が行われていない場合、ここで接続
        if (empty($myPdo)) {
            $myPdo = new MyPDO($dsn);
        }

        //データを取得
        $myPdo->setSelect('portfolio.blog_comment');
        $myPdo->setWhere(array(
            array('key' => 'article_id', 'value' => $articleId, 'operator' => '=', 'type' => PDO::PARAM_INT),
        ));
        $myPdo->setOrder(array(
            'comment_stamp ASC',
        ));
        $commentList = $myPdo->getSqlResult();

        //DBから取得できた場合、Redisに保存
        if (!empty($commentList)) {
            $commentListJson = json_encode($commentList);
            $redis->set("portfolio_comment_list_{$articleId}", $commentListJson);
        }
    }
} catch (PDOException $e) {
    $error = true;
}

//Redisからフッタ用最新ブログ記事3件の取得を試みる
$articleListFooterJson = $redis->get('portfolio_article_list_footer');
$articleListFooter = json_decode($articleListFooterJson, true);

//取得できなかった場合、DBから取得
if (empty($articleListFooter)) {
    //DBへの接続が行われていない場合、ここで接続
    if (empty($myPdo)) {
        $myPdo = new MyPDO($dsn);
    }

    //データを取得
    $myPdo->setSelect('portfolio.blog_article');
    $myPdo->setOrder(array(
        'article_stamp DESC',
    ));
    $myPdo->setLimit(3);
    $articleListFooter = $myPdo->getSqlResult();

    //DBから取得できた場合、Redisに保存
    if (!empty($articleListFooter)) {
        $articleListFooterJson = json_encode($articleListFooter);
        $redis->set('portfolio_article_list_footer', $articleListFooterJson);
    }
}

//Redisからソート優先度が高い作品3件の取得を試みる
$workListFooterJson = $redis->get('portfolio_work_list_footer');
$workListFooter = json_decode($workListFooterJson, true);

//取得できなかった場合、DBから取得
if (empty($workListFooter)) {
    //DBへの接続が行われていない場合、ここで接続
    if (empty($myPdo)) {
        $myPdo = new MyPDO($dsn);
    }

    //データを取得
    $myPdo->setSelect('portfolio.work_overview');
    $myPdo->setOrder(array(
        'work_sort_no ASC',
        'work_id ASC',
    ));
    $myPdo->setLimit(3);
    $workListFooter = $myPdo->getSqlResult();

    //DBから取得できた場合、Redisに保存
    if (!empty($workListFooter)) {
        $workListFooterJson = json_encode($workListFooter);
        $redis->set('portfolio_work_list_footer', $workListFooterJson);
    }
}

//smartyに変数をアサイン
$smarty->assign(array(
    'articleListNew'    => $articleListNew,
    'tagList'           => $tagList,
    'monthList'         => $monthList,
    'article'           => $article,
    'commentList'       => $commentList,
    'articleListFooter' => $articleListFooter,
    'workListFooter'    => $workListFooter,
    'nowYear'           => $nowYear,
));

//article.htmlを表示
$smarty->display("../apps/blog/article/article.html");

exit;
