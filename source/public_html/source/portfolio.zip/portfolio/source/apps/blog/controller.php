<?php
# -----------------------------
# ポートフォリオサイト本体 ブログページコントローラ
# 2018.07.20 s0hiba 初版作成
# 2021.01.13 s0hiba パス構造を変更
# 2021.04.26 s0hiba プロジェクトディレクトリパスを変数化
# -----------------------------


//パスに応じて処理を切り分ける
switch ($pathQuery[1]) {
    case 'article':
    case 'list':
        include_once("{$projectDirPath}/apps/blog/{$pathQuery[1]}/controller.php");
        break;
    default:
        include_once("{$projectDirPath}/apps/blog/list/controller.php");
}

exit;
