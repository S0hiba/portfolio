<?php
# -----------------------------
# ポートフォリオサイト本体 ブログ記事ページコントローラ
# 2018.09.28 s0hiba 初版作成
# 2019.03.21 s0hiba 入力チェックを導入
# 2021.01.13 s0hiba パス構造を変更
# 2021.04.26 s0hiba プロジェクトディレクトリパスを変数化
# -----------------------------


//ブログ記事のIDとPOSTリクエストの配列を初期化
$articleId = 1;
$postArray = array();

//$pathQuery[2]が0より大きい整数であるかチェック
if (isset($pathQuery[2]) && ctype_digit(strval($pathQuery[2])) && $pathQuery[2] > 0) {
    //チェック条件を満たしているなら、IDとPOSTリクエストを取得
    $articleId = $pathQuery[2];
    $postArray = $_POST;
}

//POSTリクエストが正しい配列形式であるなら、モデルを読み込む
if (isset($postArray) && is_array($postArray) && count($postArray) > 0) {
    include_once("{$projectDirPath}/apps/blog/article/model.php");
}

//ビューを読み込む
include_once("{$projectDirPath}/apps/blog/article/view.php");

exit;
