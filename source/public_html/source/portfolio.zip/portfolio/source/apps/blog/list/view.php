<?php
# -----------------------------
# ポートフォリオサイト本体 ブログ記事一覧ページビュー
# 2018.07.20 s0hiba 初版作成
# 2019.01.06 s0hiba MyPDOクラスを使用開始
# 2019.01.28 s0hiba Redis導入
# 2019.03.23 s0hiba 入力チェックを導入
# 2019.03.24 s0hiba XSS対策導入
# 2021.01.13 s0hiba パス構造を変更
# -----------------------------


//DBへ接続
$myPdo = new MyPDO($dsn);

//Redisから最新ブログ記事5件の取得を試みる
$articleListNewJson = $redis->get('portfolio_article_list_new');
$articleListNew = json_decode($articleListNewJson, true);

//取得できなかった場合、DBから取得
if (empty($articleListNew)) {
    $myPdo->setSelect('portfolio.blog_article');
    $myPdo->setOrder(array(
        'article_stamp DESC',
    ));
    $myPdo->setLimit(5);
    $articleListNew = $myPdo->getSqlResult();

    //DBから取得できた場合、Redisに保存
    if (!empty($articleListNew)) {
        $articleListNewJson = json_encode($articleListNew);
        $redis->set('portfolio_article_list_new', $articleListNewJson);
    }
}

//Redisからブログ記事種別の取得を試みる
$tagListJson = $redis->get('portfolio_tag_list');
$tagList = json_decode($tagListJson, true);

//取得できなかった場合、DBから取得
if (empty($tagList)) {
    $myPdo->setSelect('portfolio.article_tag_master');
    $myPdo->setOrder(array(
        'article_sort_no ASC',
        'article_tag_id ASC',
    ));
    $tagList = $myPdo->getSqlResult();

    //DBから取得できた場合、Redisに保存
    if (!empty($tagList)) {
        $tagListJson = json_encode($tagList);
        $redis->set('portfolio_tag_list', $tagListJson);
    }
}

//Redisからブログ記事の投稿年月一覧の取得を試みる
$monthListJson = $redis->get('portfolio_month_list');
$monthList = json_decode($monthListJson, true);

//取得できなかった場合、DBの記事データから生成
if (empty($monthList)) {
    //ブログ記事を日付昇順で全件取得
    $myPdo->setSelect('portfolio.blog_article');
    $myPdo->setOrder(array(
        'article_stamp ASC',
    ));
    $articleListAsc = $myPdo->getSqlResult();

    //ブログ記事一覧から、ブログ記事の投稿年月一覧を作成
    if (isset($articleListAsc) && is_array($articleListAsc) && count($articleListAsc) > 0) {
        foreach ($articleListAsc as $articleData) {
            //投稿日時から年と月を取得
            $year = substr($articleData['article_stamp'], 0, 4);
            $month = substr($articleData['article_stamp'], 5, 2);

            //一覧を配列形式で作成
            $monthList[$year][$month] = $month;
        }
    }

    //生成できた場合、Redisに保存
    if (!empty($monthList)) {
        $monthListJson = json_encode($monthList);
        $redis->set('portfolio_month_list', $monthListJson);
    }
}

//各種変数を初期化
$optionPath = '';
$breadcrumb = '';
$whereArray = array();
$page = 1;

//パスのHTMLをエスケープ
$tmpPathQuery = $pathQuery;
if (isset($tmpPathQuery) && is_array($tmpPathQuery) && count($tmpPathQuery) > 0) {
    foreach ($tmpPathQuery as $key => $tmpPath) {
        $pathQuery[$key] = htmlspecialchars($tmpPath, ENT_QUOTES | ENT_HTML5, 'UTF-8');
    }
}

//DB作業を試みる
try {
    //パスに応じてデータ取得SQL文を切り分ける
    switch ($pathQuery[2]) {
        case 'backnumber':
            //現在の年と月をint型で取得
            $nowMonth = $nowDateTime->format('m');
            $intNowYear = (int)$nowYear;
            $intNowMonth = (int)$nowMonth;

            //年と月の値をint型に変換
            $intYear = (int)$pathQuery[3];
            $intMonth = (int)$pathQuery[4];

            //パスに指定された年と月の値をチェック
            if (isset($intYear) && $intYear > 0 && $intYear <= $intNowYear
             && isset($intMonth) && $intMonth > 0 && $intMonth <= 12) {
                //指定された月の最初の日と最後の日をDateTimeオブジェクトで取得
                $monthStart = new DateTime("{$pathQuery[3]}-{$pathQuery[4]}-01 00:00:00");
                $monthEnd = new DateTime("last day of {$pathQuery[3]}-{$pathQuery[4]}-01 23:59:59");

                //指定された月の最初の日が、現在の日時より前であるかチェック
                if ($monthStart < $nowDateTime) {
                    //パスのオプション部分を取得
                    $optionPath = "backnumber/{$pathQuery[3]}/{$pathQuery[4]}/";

                    //DateTimeオブジェクトを文字列へフォーマット
                    $monthStartStamp = $monthStart->format('Y-m-d H:i:s');
                    $monthEndStamp = $monthEnd->format('Y-m-d H:i:s');

                    //ブログ記事の検索条件を指定
                    $whereArray = array(
                        array('key' => 'article_stamp', 'value' => $monthStartStamp,    'operator' => '>=', 'type' => PDO::PARAM_STR),
                        array('key' => 'article_stamp', 'value' => $monthEndStamp,      'operator' => '<=', 'type' => PDO::PARAM_STR),
                    );

                    //パンくずリスト用に年月を文字列で取得
                    $breadcrumb = $monthStart->format('Y年m月');
                }
            }

            //取得対象となる記事の総数を取得
            $myPdo->setSelect('portfolio.blog_article', array(
                'COUNT(*)',
            ));
            $myPdo->setWhere($whereArray);
            $articleCount = $myPdo->getSqlResultRow();

            //記事の総数からページ総数を取得
            $pageAll = floor(($articleCount['count'] + 4) / 5);

            //パスにページ総数以下の数値が指定されていれば、表示ページを指定
            if (isset($pathQuery[5]) && ctype_digit(strval($pathQuery[5])) && $pathQuery[5] > 0 && $pathQuery[5] <= $pageAll) {
                $page = $pathQuery[5];
            }

            break;
        case 'tag':
            //パスに指定されたタグのIDの値をチェック
            if (isset($pathQuery[3]) && ctype_digit(strval($pathQuery[3])) && $pathQuery[3] > 0) {
                //パスのオプション部分を取得
                $optionPath = "tag/{$pathQuery[3]}/";

                //ブログ記事の検索条件を指定
                $whereArray = array(
                    array('key' => 'article_tag_id', 'value' => $pathQuery[3], 'operator' => '=', 'type' => PDO::PARAM_INT),
                );

                //指定された記事種別を取得
                $myPdo->setSelect('portfolio.article_tag_master');
                $myPdo->setWhere($whereArray);
                $tag = $myPdo->getSqlResultRow();

                //パンくずリスト用に記事種別名を取得
                $breadcrumb = $tag['article_tag_name'];
            }

            //取得対象となる記事の総数を取得
            $myPdo->setSelect('portfolio.blog_article', array(
                'COUNT(*)',
            ));
            $myPdo->setWhere($whereArray);
            $articleCount = $myPdo->getSqlResultRow();

            //記事の総数からページ総数を取得
            $pageAll = floor(($articleCount['count'] + 4) / 5);

            //パスに数値が指定されていれば、データ取得範囲の始点に指定する
            if (isset($pathQuery[4]) && ctype_digit(strval($pathQuery[4])) && $pathQuery[4] > 0 && $pathQuery[4] <= $pageAll) {
                $page = $pathQuery[4];
            }

            break;
        default:
            //取得対象となる記事の総数を取得
            $myPdo->setSelect('portfolio.blog_article', array(
                'COUNT(*)',
            ));
            $articleCount = $myPdo->getSqlResultRow();

            //記事の総数からページ総数を取得
            $pageAll = floor(($articleCount['count'] + 4) / 5);

            //パスに数値が指定されていれば、データ取得範囲の始点に指定する
            if (isset($pathQuery[2]) && ctype_digit(strval($pathQuery[2])) && $pathQuery[2] > 0 && $pathQuery[2] <= $pageAll) {
                $page = $pathQuery[2];
            }
    }

    //ページからOFFSETの指定値を取得
    $offset = ($page - 1) * 5;

    //ブログ記事一覧を取得
    $myPdo->setSelect('portfolio.blog_article');
    $myPdo->setJoin(array(
        'portfolio.article_tag_master' => 'article_tag_id',
    ));
    $myPdo->setWhere($whereArray);
    $myPdo->setOrder(array(
        'article_stamp DESC',
    ));
    $myPdo->setLimit(5);
    $myPdo->setOffset($offset);
    $articleList = $myPdo->getSqlResult();
} catch (PDOException $e) {
    $error = true;
}

//Redisからフッタ用最新ブログ記事3件の取得を試みる
$articleListFooterJson = $redis->get('portfolio_article_list_footer');
$articleListFooter = json_decode($articleListFooterJson, true);

//取得できなかった場合、DBから取得
if (empty($articleListFooter)) {
    $myPdo->setSelect('portfolio.blog_article');
    $myPdo->setOrder(array(
        'article_stamp DESC',
    ));
    $myPdo->setLimit(3);
    $articleListFooter = $myPdo->getSqlResult();

    //DBから取得できた場合、Redisに保存
    if (!empty($articleListFooter)) {
        $articleListFooterJson = json_encode($articleListFooter);
        $redis->set('portfolio_article_list_footer', $articleListFooterJson);
    }
}

//Redisからソート優先度が高い作品3件の取得を試みる
$workListFooterJson = $redis->get('portfolio_work_list_footer');
$workListFooter = json_decode($workListFooterJson, true);

//取得できなかった場合、DBから取得
if (empty($workListFooter)) {
    $myPdo->setSelect('portfolio.work_overview');
    $myPdo->setOrder(array(
        'work_sort_no ASC',
        'work_id ASC',
    ));
    $myPdo->setLimit(3);
    $workListFooter = $myPdo->getSqlResult();

    //DBから取得できた場合、Redisに保存
    if (!empty($workListFooter)) {
        $workListFooterJson = json_encode($workListFooter);
        $redis->set('portfolio_work_list_footer', $workListFooterJson);
    }
}

//smartyに変数をアサイン
$smarty->assign(array(
    'breadcrumb'        => $breadcrumb,
    'articleListNew'    => $articleListNew,
    'tagList'           => $tagList,
    'monthList'         => $monthList,
    'articleList'       => $articleList,
    'page'              => $page,
    'pageAll'           => $pageAll,
    'optionPath'        => $optionPath,
    'articleListFooter' => $articleListFooter,
    'workListFooter'    => $workListFooter,
    'nowYear'           => $nowYear,
));

//list.htmlを表示
$smarty->display("../apps/blog/list/list.html");

exit;
