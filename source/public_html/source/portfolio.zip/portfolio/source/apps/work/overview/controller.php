<?php
# -----------------------------
# ポートフォリオサイト本体 作品概要ページコントローラ
# 2018.10.10 s0hiba 初版作成
# 2019.03.22 s0hiba 入力チェックを導入
# 2021.01.13 s0hiba パス構造を変更
# 2021.04.26 s0hiba プロジェクトディレクトリパスを変数化
# -----------------------------


//作品IDを初期化
$workId = 1;

//$pathQuery[2]が0より大きい整数であるかチェック
if (isset($pathQuery[2]) && ctype_digit(strval($pathQuery[2])) && $pathQuery[2] > 0) {
    $workId = $pathQuery[2];
}

//ビューを読み込む
include_once("{$projectDirPath}/apps/work/overview/view.php");

exit;
