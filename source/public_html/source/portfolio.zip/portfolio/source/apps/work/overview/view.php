<?php
# -----------------------------
# ポートフォリオサイト本体 作品概要ページビュー
# 2018.10.10 s0hiba 初版作成
# 2019.01.12 s0hiba MyPDOクラスを使用開始
# 2019.01.28 s0hiba Redis導入
# 2021.01.13 s0hiba パス構造を変更
# 2021.03.24 s0hiba 技術ロゴ画像をCDNへ移行
# -----------------------------


//Redisから表示対象の作品の取得を試みる
$workJson = $redis->get("portfolio_work_data_{$workId}");
$work = json_decode($workJson, true);

//Redisから表示対象の作品に使用した技術の取得を試みる
$technologyListJson = $redis->get("portfolio_technology_list_{$workId}");
$technologyArray = json_decode($technologyListJson, true);

//DB作業を試みる
try {
    //表示対象の作品をRedisから取得できなかった場合、
    //DBから取得する
    if (empty($work)) {
        //DBへの接続が行われていない場合、ここで接続
        if (empty($myPdo)) {
            $myPdo = new MyPDO($dsn);
        }

        //データを取得
        $myPdo->setSelect('portfolio.work_overview');
        $myPdo->setWhere(array(
            array('key' => 'work_id', 'value' => $workId, 'operator' => '=', 'type' => PDO::PARAM_INT),
        ));
        $work = $myPdo->getSqlResultRow();

        //DBから取得できた場合、Redisに保存
        if (!empty($work)) {
            $workJson = json_encode($work);
            $redis->set("portfolio_work_data_{$workId}", $workJson);
        }
    }

    //表示対象の作品に使用した技術をRedisから取得できなかった場合、
    //DBから取得する
    if (empty($technologyArray)) {
        //DBへの接続が行われていない場合、ここで接続
        if (empty($myPdo)) {
            $myPdo = new MyPDO($dsn);
        }

        //データを取得
        $myPdo->setSelect('portfolio.work_technology');
        $myPdo->setJoin(array(
            'portfolio.technology_master' => 'technology_id',
        ));
        $myPdo->setWhere(array(
            array('key' => 'work_id', 'value' => $workId, 'operator' => '=', 'type' => PDO::PARAM_INT),
        ));
        $myPdo->setOrder(array(
            'technology_id ASC',
        ));
        $technologyArray = $myPdo->getSqlResult();

        //DBから取得できた場合、Redisに保存
        if (!empty($technologyArray)) {
            $technologyListJson = json_encode($technologyArray);
            $redis->set("portfolio_technology_list_{$workId}", $technologyListJson);
        }
    }
} catch (PDOException $e) {
    $error = true;
}

//技術名から画像ファイルパスを生成
if (isset($technologyArray) && is_array($technologyArray) && count($technologyArray) > 0) {
    foreach ($technologyArray as $technologyData) {
        //技術名を小文字に、半角スペースをアンダーバーに変換
        $technologyNameLower = strtolower($technologyData['technology_name']);
        $imageName = str_replace(' ', '_', $technologyNameLower);

        //パスと結合
        $technologyImage = "https://cdn.s0hiba.site/img/{$imageName}.png";

        //表示用の配列を作成
        $technologyList[] = array(
            'technology_name'   => $technologyData['technology_name'],
            'technology_image'  => $technologyImage,
        );
    }
}

//Redisからフッタ用最新ブログ記事3件の取得を試みる
$articleListFooterJson = $redis->get('portfolio_article_list_footer');
$articleListFooter = json_decode($articleListFooterJson, true);

//取得できなかった場合、DBから取得
if (empty($articleListFooter)) {
    //DBへの接続が行われていない場合、ここで接続
    if (empty($myPdo)) {
        $myPdo = new MyPDO($dsn);
    }

    //データを取得
    $myPdo->setSelect('portfolio.blog_article');
    $myPdo->setOrder(array(
        'article_stamp DESC',
    ));
    $myPdo->setLimit(3);
    $articleListFooter = $myPdo->getSqlResult();

    //DBから取得できた場合、Redisに保存
    if (!empty($articleListFooter)) {
        $articleListFooterJson = json_encode($articleListFooter);
        $redis->set('portfolio_article_list_footer', $articleListFooterJson);
    }
}

//Redisからソート優先度が高い作品3件の取得を試みる
$workListFooterJson = $redis->get('portfolio_work_list_footer');
$workListFooter = json_decode($workListFooterJson, true);

//取得できなかった場合、DBから取得
if (empty($workListFooter)) {
    //DBへの接続が行われていない場合、ここで接続
    if (empty($myPdo)) {
        $myPdo = new MyPDO($dsn);
    }

    //データを取得
    $myPdo->setSelect('portfolio.work_overview');
    $myPdo->setOrder(array(
        'work_sort_no ASC',
        'work_id ASC',
    ));
    $myPdo->setLimit(3);
    $workListFooter = $myPdo->getSqlResult();

    //DBから取得できた場合、Redisに保存
    if (!empty($workListFooter)) {
        $workListFooterJson = json_encode($workListFooter);
        $redis->set('portfolio_work_list_footer', $workListFooterJson);
    }
}

//smartyに変数をアサイン
$smarty->assign(array(
    'work'              => $work,
    'technologyList'    => $technologyList,
    'articleListFooter' => $articleListFooter,
    'workListFooter'    => $workListFooter,
    'nowYear'           => $nowYear,
));

//overview.htmlを表示
$smarty->display('../apps/work/overview/overview.html');

exit;
