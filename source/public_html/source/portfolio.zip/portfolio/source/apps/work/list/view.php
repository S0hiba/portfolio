<?php
# -----------------------------
# ポートフォリオサイト本体 作品一覧ページビュー
# 2018.07.20 s0hiba 初版作成
# 2019.01.12 s0hiba MyPDOクラスを使用開始
# 2019.01.28 s0hiba Redis導入
# 2021.01.13 s0hiba パス構造を変更
# -----------------------------


//Redisから作品一覧の取得を試みる
$workListJson = $redis->get('portfolio_work_list');
$workList = json_decode($workListJson, true);

//取得できなかった場合、DBから取得
if (empty($workList)) {
    //DBへの接続が行われていない場合、ここで接続
    if (empty($myPdo)) {
        $myPdo = new MyPDO($dsn);
    }

    //データを取得
    $myPdo->setSelect('portfolio.work_overview');
    $myPdo->setOrder(array(
        'work_sort_no ASC',
        'work_id ASC',
    ));
    $workList = $myPdo->getSqlResult();

    //DBから取得できた場合、Redisに保存
    if (!empty($workList)) {
        $workListJson = json_encode($workList);
        $redis->set('portfolio_work_list', $workListJson);
    }
}

//Redisからフッタ用最新ブログ記事3件の取得を試みる
$articleListFooterJson = $redis->get('portfolio_article_list_footer');
$articleListFooter = json_decode($articleListFooterJson, true);

//取得できなかった場合、DBから取得
if (empty($articleListFooter)) {
    //DBへの接続が行われていない場合、ここで接続
    if (empty($myPdo)) {
        $myPdo = new MyPDO($dsn);
    }

    //データを取得
    $myPdo->setSelect('portfolio.blog_article');
    $myPdo->setOrder(array(
        'article_stamp DESC',
    ));
    $myPdo->setLimit(3);
    $articleListFooter = $myPdo->getSqlResult();

    //DBから取得できた場合、Redisに保存
    if (!empty($articleListFooter)) {
        $articleListFooterJson = json_encode($articleListFooter);
        $redis->set('portfolio_article_list_footer', $articleListFooterJson);
    }
}

//Redisからソート優先度が高い作品3件の取得を試みる
$workListFooterJson = $redis->get('portfolio_work_list_footer');
$workListFooter = json_decode($workListFooterJson, true);

//取得できなかった場合、DBから取得
if (empty($workListFooter)) {
    //DBへの接続が行われていない場合、ここで接続
    if (empty($myPdo)) {
        $myPdo = new MyPDO($dsn);
    }

    //データを取得
    $myPdo->setSelect('portfolio.work_overview');
    $myPdo->setOrder(array(
        'work_sort_no ASC',
        'work_id ASC',
    ));
    $myPdo->setLimit(3);
    $workListFooter = $myPdo->getSqlResult();

    //DBから取得できた場合、Redisに保存
    if (!empty($workListFooter)) {
        $workListFooterJson = json_encode($workListFooter);
        $redis->set('portfolio_work_list_footer', $workListFooterJson);
    }
}

//smartyに変数をアサイン
$smarty->assign(array(
    'workList'          => $workList,
    'articleListFooter' => $articleListFooter,
    'workListFooter'    => $workListFooter,
    'nowYear'           => $nowYear,
));

//list.htmlを表示
$smarty->display('../apps/work/list/list.html');

exit;
