<?php
# -----------------------------
# ポートフォリオサイト本体 トップページビュー
# 2018.07.20 s0hiba 初版作成
# 2019.01.12 s0hiba MyPDOクラスを使用開始
# 2019.01.28 s0hiba Redis導入
# 2021.01.13 s0hiba パス構造を変更
# -----------------------------


//Redisから最新更新履歴5件の取得を試みる
$logListJson = $redis->get('portfolio_log_list');
$logArray = json_decode($logListJson, true);

//取得できなかった場合、DBから取得
if (empty($logArray)) {
    //DBへの接続が行われていない場合、ここで接続
    if (empty($myPdo)) {
        $myPdo = new MyPDO($dsn);
    }

    //データを取得
    $myPdo->setSelect('portfolio.update_log');
    $myPdo->setJoin(array(
        'portfolio.log_tag_master' => 'log_tag_id',
    ));
    $myPdo->setOrder(array(
        'log_stamp DESC',
    ));
    $myPdo->setLimit(5);
    $logArray = $myPdo->getSqlResult();

    //DBから取得できた場合、Redisに保存
    if (!empty($logArray)) {
        $logListJson = json_encode($logArray);
        $redis->set('portfolio_log_list', $logListJson);
    }
}

//更新履歴の更新日から時間部分を削除
if (isset($logArray) && is_array($logArray) && count($logArray) > 0) {
    foreach ($logArray as $logData) {
        $logDate = substr($logData['log_stamp'], 0, 10);
        $logList[] = array(
            'log_id'            => $logData['log_id'],
            'log_date'          => $logDate,
            'log_tag_id'        => $logData['log_tag_id'],
            'log_text'          => $logData['log_text'],
            'log_target_id'     => $logData['log_target_id'],
            'log_link'          => $logData['log_link'],
            'log_tag_name'      => $logData['log_tag_name'],
            'log_tag_icon'      => $logData['log_tag_icon'],
        );
    }
}

//Redisからフッタ用最新ブログ記事3件の取得を試みる
$articleListFooterJson = $redis->get('portfolio_article_list_footer');
$articleListFooter = json_decode($articleListFooterJson, true);

//取得できなかった場合、DBから取得
if (empty($articleListFooter)) {
    //DBへの接続が行われていない場合、ここで接続
    if (empty($myPdo)) {
        $myPdo = new MyPDO($dsn);
    }

    //データを取得
    $myPdo->setSelect('portfolio.blog_article');
    $myPdo->setOrder(array(
        'article_stamp DESC',
    ));
    $myPdo->setLimit(3);
    $articleListFooter = $myPdo->getSqlResult();

    //DBから取得できた場合、Redisに保存
    if (!empty($articleListFooter)) {
        $articleListFooterJson = json_encode($articleListFooter);
        $redis->set('portfolio_article_list_footer', $articleListFooterJson);
    }
}

//Redisからソート優先度が高い作品3件の取得を試みる
$workListFooterJson = $redis->get('portfolio_work_list_footer');
$workListFooter = json_decode($workListFooterJson, true);

//取得できなかった場合、DBから取得
if (empty($workListFooter)) {
    //DBへの接続が行われていない場合、ここで接続
    if (empty($myPdo)) {
        $myPdo = new MyPDO($dsn);
    }

    //データを取得
    $myPdo->setSelect('portfolio.work_overview');
    $myPdo->setOrder(array(
        'work_sort_no ASC',
        'work_id ASC',
    ));
    $myPdo->setLimit(3);
    $workListFooter = $myPdo->getSqlResult();

    //DBから取得できた場合、Redisに保存
    if (!empty($workListFooter)) {
        $workListFooterJson = json_encode($workListFooter);
        $redis->set('portfolio_work_list_footer', $workListFooterJson);
    }
}

//smartyに変数をアサイン
$smarty->assign(array(
    'logList'           => $logList,
    'articleListFooter' => $articleListFooter,
    'workListFooter'    => $workListFooter,
    'nowYear'           => $nowYear,
));

//top.htmlを表示
$smarty->display('../apps/top/top.html');

exit;
