<?php
# -----------------------------
# ポートフォリオサイト本体 プロフィールページビュー
# 2018.07.20 s0hiba 初版作成
# 2019.01.06 s0hiba MyPDOクラスを使用開始
# 2019.01.28 s0hiba Redis導入
# 2020.08.30 s0hiba スキル一覧表示に必要なデータの取得処理を追加
# 2021.01.13 s0hiba パス構造を変更
# 2021.01.20 s0hiba 技術ロゴの画像ファイルパス変更
# 2021.03.24 s0hiba 技術ロゴ画像をCDNへ移行
# -----------------------------


//誕生日から年齢を算出
$birthDay = new DateTime('1995-09-18');
$ageInterval = $nowDateTime->diff($birthDay);
$age = $ageInterval->format('%Y');

//Redisから技術種別一覧の取得を試みる
$tagListJson = $redis->get('portfolio_technology_tag_list');
$tagArray = json_decode($tagListJson, true);

//取得できなかった場合、DBから取得
if (empty($tagArray)) {
    //DBへの接続が行われていない場合、ここで接続
    if (empty($myPdo)) {
        $myPdo = new MyPDO($dsn);
    }

    //データを取得
    $myPdo->setSelect('portfolio.technology_tag_master');
    $myPdo->setOrder(array('technology_tag_sort_no ASC'));
    $tagArray = $myPdo->getSqlResult();

    //DBから取得できた場合、Redisに保存
    if (!empty($tagArray)) {
        $tagListJson = json_encode($tagArray);
        $redis->set('portfolio_technology_tag_list', $tagListJson);
    }
}

//IDをキーとする配列を生成し、Redisに保存
if (isset($tagArray) && is_array($tagArray) && count($tagArray) > 0) {
    foreach ($tagArray as $tagRow) {
        $tagList[$tagRow['technology_tag_id']] = $tagRow;
    }
}

//Redisからスキル一覧の取得を試みる
$skillListJson = $redis->get('portfolio_skill_list');
$skillArray = json_decode($skillListJson, true);

//取得できなかった場合、DBから取得
if (empty($skillArray)) {
    //DBへの接続が行われていない場合、ここで接続
    if (empty($myPdo)) {
        $myPdo = new MyPDO($dsn);
    }

    //データを取得
    $myPdo->setSelect('portfolio.technology_skill');
    $myPdo->setJoin(array(
        'portfolio.technology_master'       => 'technology_id',
        'portfolio.technology_tag_master'   => 'technology_tag_id',
    ));
    $myPdo->setOrder(array(
        'technology_tag_sort_no',
        'skill_sort_no ASC'
    ));
    $skillArray = $myPdo->getSqlResult();

    //DBから取得できた場合、Redisに保存
    if (!empty($skillArray)) {
        $skillListJson = json_encode($skillArray);
        $redis->set('portfolio_skill_list', $skillListJson);
    }
}

//スキル一覧から、技術種別ごとのスキル一覧を作成
if (isset($skillArray) && is_array($skillArray) && count($skillArray) > 0) {
    foreach($skillArray as $skillRow) {
        //技術名から画像ファイルパスを生成
        $technologyNameLower = strtolower($skillRow['technology_name']);
        $imageName = str_replace(' ', '_', $technologyNameLower);
        $skillRow['technology_image'] = "https://cdn.s0hiba.site/img/{$imageName}.png";

        //技術種別ごとのスキル一覧の配列に要素を追加
        $skillList[$skillRow['technology_tag_id']][] = $skillRow;
    }
}

//Redisからフッタ用最新ブログ記事3件の取得を試みる
$articleListFooterJson = $redis->get('portfolio_article_list_footer');
$articleListFooter = json_decode($articleListFooterJson, true);

//取得できなかった場合、DBから取得
if (empty($articleListFooter)) {
    //DBへの接続が行われていない場合、ここで接続
    if (empty($myPdo)) {
        $myPdo = new MyPDO($dsn);
    }

    //データを取得
    $myPdo->setSelect('portfolio.blog_article');
    $myPdo->setOrder(array(
        'article_stamp DESC',
    ));
    $myPdo->setLimit(3);
    $articleListFooter = $myPdo->getSqlResult();

    //DBから取得できた場合、Redisに保存
    if (!empty($articleListFooter)) {
        $articleListFooterJson = json_encode($articleListFooter);
        $redis->set('portfolio_article_list_footer', $articleListFooterJson);
    }
}

//Redisからソート優先度が高い作品3件の取得を試みる
$workListFooterJson = $redis->get('portfolio_work_list_footer');
$workListFooter = json_decode($workListFooterJson, true);

//取得できなかった場合、DBから取得
if (empty($workListFooter)) {
    //DBへの接続が行われていない場合、ここで接続
    if (empty($myPdo)) {
        $myPdo = new MyPDO($dsn);
    }

    //データを取得
    $myPdo->setSelect('portfolio.work_overview');
    $myPdo->setOrder(array(
        'work_sort_no ASC',
        'work_id ASC',
    ));
    $myPdo->setLimit(3);
    $workListFooter = $myPdo->getSqlResult();

    //DBから取得できた場合、Redisに保存
    if (!empty($workListFooter)) {
        $workListFooterJson = json_encode($workListFooter);
        $redis->set('portfolio_work_list_footer', $workListFooterJson);
    }
}

//smartyに変数をアサイン
$smarty->assign(array(
    'age'               => $age,
    'tagList'           => $tagList,
    'skillList'         => $skillList,
    'articleListFooter' => $articleListFooter,
    'workListFooter'    => $workListFooter,
    'nowYear'           => $nowYear,
));

//profile.htmlを表示
$smarty->display('../apps/profile/profile.html');

exit;
