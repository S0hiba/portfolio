# www.s0hiba.site

## Overview
- S_hiba名義のポートフォリオサイト
- https://s0hiba.herokuapp.com
    - 現行のherokuの無料ドメイン
- https://www.s0hiba.site
    - 移行予定のドメイン
- https://s0hiba.herokuapp.com/admin/
    - 現行のherokuの管理ツール

## Discription
- S_hiba名義でエンジニアとしてのアウトプットを行うポートフォリオサイト
- 自己紹介(スキルセット)/ブログ/作品を主なコンテンツとする
